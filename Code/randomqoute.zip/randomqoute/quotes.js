const quotes = [
{
quote:"Stay hungry. Stay foolish.",
author:"Steve Jobs"
},
{
quote:"The future depends on what you do today.",
author:"Mahatma Gandhi"
},
{
quote:"Dream big and dare to fail.",
author:"Norman Vaughan"
},
{
quote:"Success is not final, failure is not fatal: it is the courage to continue that counts.",
author:"Winston Churchill"
},
{
quote:"Believe you can and you're halfway there.",
author:"Theodore Roosevelt"
},
{
quote:"Your time is limited, so don't waste it living someone else's life.",
author:"Steve Jobs"
},
{
quote:"The best way to predict the future is to create it.",
author:"Peter Drucker"
},
{
quote:"If you can dream it, you can do it.",
author:"Walt Disney"
},
{
quote:"Do one thing every day that scares you.",
author:"Eleanor Roosevelt"
},
{
quote:"Don't watch the clock; do what it does. Keep going.",
author:"Sam Levenson"
},
{
quote:"Everything you've ever wanted is on the other side of fear.",
author:"George Addair"
},
{
quote:"Action is the foundational key to all success.",
author:"Pablo Picasso"
},
{
quote:"Success usually comes to those who are too busy to be looking for it.",
author:"Henry David Thoreau"
},
{
quote:"It always seems impossible until it's done.",
author:"Nelson Mandela"
},
{
quote:"The harder you work for something, the greater you'll feel when you achieve it.",
author:"Anonymous"
},
{
quote:"Push yourself because no one else is going to do it for you.",
author:"Anonymous"
},
{
quote:"Great things never come from comfort zones.",
author:"Anonymous"
},
{
quote:"Dream it. Wish it. Do it.",
author:"Anonymous"
},
{
quote:"Don't stop when you're tired. Stop when you're done.",
author:"Anonymous"
},
{
quote:"Little things make big days.",
author:"Anonymous"
}
];

console.log(quotes);