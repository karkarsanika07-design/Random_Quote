
/// ===================== ELEMENTS =====================

const quote = document.getElementById("quote");
const author = document.getElementById("author");

const newQuote = document.getElementById("newQuote");
const copyBtn = document.getElementById("copyBtn");
const shareBtn = document.getElementById("shareBtn");
const tweetBtn = document.getElementById("tweetBtn");
const themeBtn = document.getElementById("themeBtn");

// ===================== RANDOM QUOTE =====================

newQuote.addEventListener("click", generateQuote);

function generateQuote(){

    const random = Math.floor(Math.random() * quotes.length);

    quote.innerText = `"${quotes[random].quote}"`;
    author.innerText = "— " + quotes[random].author;
}
// ===================== COPY =====================

copyBtn.addEventListener("click",()=>{

navigator.clipboard.writeText(quote.innerText + " " + author.innerText);

alert("Copied!");
});

// ===================== WHATSAPP =====================

shareBtn.addEventListener("click",()=>{

const text = quote.innerText + "\n" + author.innerText;

window.open("https://wa.me/?text=" + encodeURIComponent(text),"_blank");

});

// ===================== X =====================

tweetBtn.addEventListener("click",()=>{

const text = quote.innerText + " " + author.innerText;

window.open("https://twitter.com/intent/tweet?text=" + encodeURIComponent(text),"_blank");

});

// ===================== THEME TOGGLE =====================

themeBtn.addEventListener("click",()=>{

document.body.classList.toggle("dark");

if(document.body.classList.contains("dark")){
  themeBtn.innerHTML = "☀ Light";
}else{
  themeBtn.innerHTML = "🌙 Theme";
}

});

// ===================== FIRST LOAD =====================

generateQuote();
function goHome(){

window.location.href="demo.html";

}