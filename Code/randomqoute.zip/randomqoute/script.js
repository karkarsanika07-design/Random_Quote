// ===============================
// DOM ELEMENTS
// ===============================

const quote = document.getElementById("quote");
const author = document.getElementById("author");

const newQuote = document.getElementById("newQuote");
const copyBtn = document.getElementById("copyBtn");
const shareBtn = document.getElementById("shareBtn");
const tweetBtn = document.getElementById("tweetBtn");
const themeBtn = document.getElementById("themeBtn");

// ===============================
// BACKGROUND COLORS
// ===============================

const backgrounds = [

"linear-gradient(135deg,#0f172a,#1e293b)",
"linear-gradient(135deg,#111827,#312e81)",
"linear-gradient(135deg,#0f2027,#203a43,#2c5364)",
"linear-gradient(135deg,#232526,#414345)",
"linear-gradient(135deg,#141E30,#243B55)",
"linear-gradient(135deg,#2C3E50,#4CA1AF)",
"linear-gradient(135deg,#000000,#434343)",
"linear-gradient(135deg,#1f1c2c,#928dab)"

];

// ===============================
// RANDOM QUOTE
// ===============================

function generateQuote(){

const random = Math.floor(Math.random() * quotes.length);

quote.style.opacity = 0;
author.style.opacity = 0;

setTimeout(()=>{

quote.innerText = `"${quotes[random].quote}"`;
author.innerText = "— " + quotes[random].author;

quote.style.opacity = 1;
author.style.opacity = 1;

},300);

const bg = backgrounds[Math.floor(Math.random()*backgrounds.length)];
document.body.style.background = bg;

}

// ===============================
// COPY
// ===============================

copyBtn.addEventListener("click",()=>{

const text = `${quote.innerText}\n${author.innerText}`;

navigator.clipboard.writeText(text);

copyBtn.innerHTML="✅ Copied!";

setTimeout(()=>{

copyBtn.innerHTML='<i class="fa-solid fa-copy"></i> Copy';

},1500);

});

// ===============================
// WHATSAPP SHARE
// ===============================

shareBtn.addEventListener("click",()=>{

const text = `${quote.innerText}\n${author.innerText}`;

window.open(
`https://wa.me/?text=${encodeURIComponent(text)}`,
"_blank"
);

});

// ===============================
// X SHARE
// ===============================

tweetBtn.addEventListener("click",()=>{

const text = `${quote.innerText}\n${author.innerText}`;

window.open(
`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`,
"_blank"
);

});

// ===============================
// THEME
// ===============================

themeBtn.addEventListener("click",()=>{

document.body.classList.toggle("dark");

if(document.body.classList.contains("dark")){

localStorage.setItem("theme","dark");

themeBtn.innerHTML='<i class="fa-solid fa-sun"></i> Light';

}else{

localStorage.setItem("theme","light");

themeBtn.innerHTML='<i class="fa-solid fa-moon"></i> Theme';

}

});

// ===============================
// LOAD SAVED THEME
// ===============================

if(localStorage.getItem("theme")==="dark"){

document.body.classList.add("dark");

themeBtn.innerHTML='<i class="fa-solid fa-sun"></i> Light';

}

// ===============================
// NEW QUOTE BUTTON
// ===============================

newQuote.addEventListener("click",generateQuote);

// ===============================
// FIRST QUOTE
// ===============================

generateQuote();

function goHome(){

window.location.href="demo.html";

}