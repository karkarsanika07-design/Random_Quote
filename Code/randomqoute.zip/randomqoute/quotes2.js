const quotes = [

{
quote:"Believe you can and you're halfway there.",
author:"Theodore Roosevelt"
},

{
quote:"The future depends on what you do today.",
author:"Mahatma Gandhi"
},

{
quote:"It always seems impossible until it's done.",
author:"Nelson Mandela"
},

{
quote:"Don't watch the clock; do what it does. Keep going.",
author:"Sam Levenson"
},

{
quote:"Success is the sum of small efforts, repeated day in and day out.",
author:"Robert Collier"
},

{
quote:"The secret of getting ahead is getting started.",
author:"Mark Twain"
},

{
quote:"Great things are done by a series of small things brought together.",
author:"Vincent van Gogh"
},

{
quote:"You don't have to be great to start, but you have to start to be great.",
author:"Zig Ziglar"
},

{
quote:"The harder the conflict, the greater the triumph.",
author:"George Washington"
},

{
quote:"Do what you can, with what you have, where you are.",
author:"Theodore Roosevelt"
},

{
quote:"Success is not final, failure is not fatal: it is the courage to continue that counts.",
author:"Winston Churchill"
},

{
quote:"The only way to do great work is to love what you do.",
author:"Steve Jobs"
},

{
quote:"Dream big and dare to fail.",
author:"Norman Vincent Peale"
},

{
quote:"A goal without a plan is just a wish.",
author:"Antoine de Saint-Exupéry"
},

{
quote:"Don't limit your challenges. Challenge your limits.",
author:"Jerry Dunn"
},

{
quote:"Your limitation—it's only your imagination.",
author:"Unknown"
},

{
quote:"The best way to predict the future is to create it.",
author:"Peter Drucker"
},

{
quote:"Act as if what you do makes a difference. It does.",
author:"William James"
},

{
quote:"Failure is simply the opportunity to begin again, this time more intelligently.",
author:"Henry Ford"
},

{
quote:"What you get by achieving your goals is not as important as what you become by achieving your goals.",
author:"Zig Ziglar"
}

];